# Control de Materiales - Preparatoria

Sistema de control de materiales convertido en aplicación de escritorio para Windows.

## Características

- Inicio de sesión de administrador
- Inventario
- Entrega de materiales
- Devoluciones
- Historial de movimientos
- Guardado local de información
- Instalador para Windows
- Versión portable

## Generar el EXE automáticamente

El repositorio incluye GitHub Actions.

1. Sube este proyecto a GitHub.
2. Ve a **Actions**.
3. Ejecuta **Generar EXE de Windows**.
4. Cuando termine, entra a **Releases**.
5. Allí estará el instalador `.exe` y la versión portable.

También se puede generar una Release creando un tag con formato `v1.0.0`.

## Ejecutar localmente

```bash
npm install
npm start
```
