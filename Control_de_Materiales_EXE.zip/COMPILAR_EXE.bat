@echo off
title Compilar Control de Materiales
echo ==========================================
echo   CONTROL DE MATERIALES - COMPILADOR
echo ==========================================
echo.

where node >nul 2>nul
if errorlevel 1 (
    echo ERROR: Node.js no esta instalado.
    echo Instala Node.js LTS y vuelve a ejecutar este archivo.
    pause
    exit /b 1
)

echo Instalando dependencias...
call npm install
if errorlevel 1 (
    echo ERROR durante npm install.
    pause
    exit /b 1
)

echo.
echo Generando el EXE...
call npm run dist
if errorlevel 1 (
    echo ERROR durante la compilacion.
    pause
    exit /b 1
)

echo.
echo COMPILACION TERMINADA.
echo Revisa la carpeta "dist".
pause
